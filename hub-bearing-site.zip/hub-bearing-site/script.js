(function () {
  "use strict";

  const body = document.body;
  const header = document.getElementById("siteHeader");
  const loader = document.getElementById("loader");
  const navToggle = document.getElementById("navToggle");
  const navPanel = document.getElementById("navPanel");
  const themeToggle = document.getElementById("themeToggle");
  const backToTop = document.getElementById("backToTop");
  const heroSlider = document.getElementById("heroSlider");
  const heroSlides = document.querySelectorAll(".hero__slide");
  const heroEyebrow = document.getElementById("heroEyebrow");
  const heroTitle = document.getElementById("heroTitle");
  const heroSubhead = document.getElementById("heroSubhead");
  const heroPrev = document.getElementById("heroPrev");
  const heroNext = document.getElementById("heroNext");
  const heroDots = document.getElementById("heroDots");
  const reveals = document.querySelectorAll(".reveal");
  const counters = document.querySelectorAll("[data-counter]");
  const filterButtons = document.querySelectorAll("[data-filter]");
  const productSearch = document.getElementById("productSearch");
  const categoryCards = document.querySelectorAll(".category-card");
  const testimonialTrack = document.getElementById("testimonialTrack");
  const prevTestimonial = document.getElementById("prevTestimonial");
  const nextTestimonial = document.getElementById("nextTestimonial");
  const inquiryForm = document.getElementById("inquiryForm");
  const formStatus = document.getElementById("formStatus");
  const contactForm = document.getElementById("contactForm");
  const contactFormStatus = document.getElementById("contactFormStatus");

  let activeFilter = "all";
  let heroIndex = 0;
  let heroTimer;
  let testimonialIndex = 0;
  let counterStarted = false;

  const heroCopy = [
    {
      eyebrow: "Global OEM Bearing Manufacturer",
      title: "Precision Wheel Hub Bearings for Global Automotive Markets",
      subhead: "4000+ SKU Coverage | OEM Manufacturing | Global Export"
    },
    {
      eyebrow: "Advanced Manufacturing Capability",
      title: "Engineered Hub Assembly Units for Demanding Supply Chains",
      subhead: "CNC Machining | Automated Assembly | Stable Batch Quality"
    },
    {
      eyebrow: "Distributor Growth Program",
      title: "Factory Direct Wheel-End Solutions for Worldwide Partners",
      subhead: "Fast-Moving SKUs | Technical Support | Export to 80+ Countries"
    }
  ];

  window.addEventListener("load", () => {
    if (loader) window.setTimeout(() => loader.classList.add("is-hidden"), 450);
  });

  function onScroll() {
    const scrolled = window.scrollY > 18;
    if (header) header.classList.toggle("is-scrolled", scrolled);
    if (backToTop) backToTop.classList.toggle("is-visible", window.scrollY > 700);
  }

  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  if (navToggle && navPanel) {
    navToggle.addEventListener("click", () => {
      const isOpen = navPanel.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    navPanel.addEventListener("click", (event) => {
      if (event.target.matches("a")) {
        navPanel.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  const savedTheme = localStorage.getItem("axora-theme");
  if (savedTheme === "light") {
    body.dataset.theme = "light";
  }

  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      const nextTheme = body.dataset.theme === "light" ? "dark" : "light";
      if (nextTheme === "light") {
        body.dataset.theme = "light";
        localStorage.setItem("axora-theme", "light");
      } else {
        body.removeAttribute("data-theme");
        localStorage.setItem("axora-theme", "dark");
      }
    });
  }

  if (backToTop) {
    backToTop.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  function renderHeroDots() {
    heroSlides.forEach((_, index) => {
      const dot = document.createElement("button");
      dot.className = "hero__dot";
      dot.type = "button";
      dot.setAttribute("aria-label", `Go to hero slide ${index + 1}`);
      dot.addEventListener("click", () => {
        setHeroSlide(index);
        restartHeroTimer();
      });
      if (heroDots) heroDots.appendChild(dot);
    });
  }

  function setHeroSlide(index) {
    heroIndex = (index + heroSlides.length) % heroSlides.length;
    heroSlides.forEach((slide, slideIndex) => {
      slide.classList.toggle("is-active", slideIndex === heroIndex);
    });
    if (heroDots) {
      heroDots.querySelectorAll(".hero__dot").forEach((dot, dotIndex) => {
        dot.classList.toggle("is-active", dotIndex === heroIndex);
      });
    }

    const copy = heroCopy[heroIndex];
    if (heroEyebrow) heroEyebrow.textContent = copy.eyebrow;
    if (heroTitle) heroTitle.textContent = copy.title;
    if (heroSubhead) heroSubhead.textContent = copy.subhead;
  }

  function nextHeroSlide() {
    setHeroSlide(heroIndex + 1);
  }

  function restartHeroTimer() {
    window.clearInterval(heroTimer);
    heroTimer = window.setInterval(nextHeroSlide, 6500);
  }

  if (heroSlider && heroSlides.length && heroPrev && heroNext && heroDots) {
    renderHeroDots();
    setHeroSlide(0);
    restartHeroTimer();
    heroPrev.addEventListener("click", () => {
      setHeroSlide(heroIndex - 1);
      restartHeroTimer();
    });
    heroNext.addEventListener("click", () => {
      nextHeroSlide();
      restartHeroTimer();
    });
    heroSlider.addEventListener("mouseenter", () => window.clearInterval(heroTimer));
    heroSlider.addEventListener("mouseleave", restartHeroTimer);
  }

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
      }
    });
  }, { threshold: 0.16 });

  reveals.forEach((element) => revealObserver.observe(element));

  function animateCounters() {
    if (counterStarted) return;
    counterStarted = true;

    counters.forEach((counter) => {
      const target = Number(counter.dataset.counter);
      const duration = 1500;
      const start = performance.now();

      function tick(now) {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        counter.textContent = Math.floor(target * eased).toLocaleString();
        if (progress < 1) requestAnimationFrame(tick);
      }

      requestAnimationFrame(tick);
    });
  }

  const statsObserver = new IntersectionObserver((entries) => {
    if (entries.some((entry) => entry.isIntersecting)) animateCounters();
  }, { threshold: 0.35 });

  const statsSection = document.querySelector(".stats-section");
  if (statsSection) statsObserver.observe(statsSection);

  function filterProducts() {
    const query = productSearch ? productSearch.value.trim().toLowerCase() : "";

    categoryCards.forEach((card) => {
      const matchesFilter = activeFilter === "all" || card.dataset.category === activeFilter;
      const matchesSearch = !query || card.dataset.name.toLowerCase().includes(query) || card.textContent.toLowerCase().includes(query);
      card.style.display = matchesFilter && matchesSearch ? "" : "none";
    });
  }

  filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
      filterButtons.forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      activeFilter = button.dataset.filter;
      filterProducts();
    });
  });

  if (productSearch) productSearch.addEventListener("input", filterProducts);

  function updateCarousel() {
    if (testimonialTrack) testimonialTrack.style.transform = `translateX(-${testimonialIndex * 100}%)`;
  }

  function goToNextTestimonial() {
    if (!testimonialTrack) return;
    testimonialIndex = (testimonialIndex + 1) % testimonialTrack.children.length;
    updateCarousel();
  }

  if (testimonialTrack && prevTestimonial && nextTestimonial) {
    prevTestimonial.addEventListener("click", () => {
      testimonialIndex = (testimonialIndex - 1 + testimonialTrack.children.length) % testimonialTrack.children.length;
      updateCarousel();
    });

    nextTestimonial.addEventListener("click", goToNextTestimonial);
    window.setInterval(goToNextTestimonial, 6000);
  }

  function handleInquirySubmit(form, statusElement, event) {
    event.preventDefault();
    statusElement.className = "form-status";

    const data = new FormData(form);
    const requiredFields = ["name", "company", "country", "email", "whatsapp", "interest", "message"];
    const missingField = requiredFields.find((field) => !String(data.get(field) || "").trim());
    const email = String(data.get("email") || "").trim();
    const emailIsValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

    if (missingField) {
      statusElement.textContent = "Please complete all required fields before submitting.";
      statusElement.classList.add("is-error");
      form.elements[missingField].focus();
      return;
    }

    if (!emailIsValid) {
      statusElement.textContent = "Please enter a valid business email address.";
      statusElement.classList.add("is-error");
      form.elements.email.focus();
      return;
    }

    statusElement.textContent = "Inquiry prepared. Connect this form to your CRM or email endpoint for production submission.";
    statusElement.classList.add("is-success");
    form.reset();
  }

  if (inquiryForm && formStatus) {
    inquiryForm.addEventListener("submit", (event) => handleInquirySubmit(inquiryForm, formStatus, event));
  }

  if (contactForm && contactFormStatus) {
    contactForm.addEventListener("submit", (event) => handleInquirySubmit(contactForm, contactFormStatus, event));
  }
})();
